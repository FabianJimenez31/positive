Instalación
-------------------------

- Crear Base de Datos en MySQL y un usuario con privilegios sobre la misma
- Renombrar application/config/database.php.tmpl a application/config/database.php
- Editar application/config/database.php con la información de la Base de Datos
- El usuario/contraseña iniciales son admin/mercurio

