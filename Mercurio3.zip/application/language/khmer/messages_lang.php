<?php
$lang['messages_sent_messages'] = 'សារ​ដែល​បាន​ផ្ញើ';
$lang['messages_no_messages'] = 'ពុំ​មាន​សារ';
$lang['messages_inbox'] = 'ប្រអប់ទទួល';
$lang['messages_message_deleted'] = 'សារ​បាន​លុប​ដោយ​ជោគជ័យ';
$lang['messages_employees_required'] = 'អ្នក​យ៉ាងហោចណាស់​ត្រូវ​ជ្រើស​និយោជិក​មួយ';
$lang['messages_locations_required'] = 'អ្នក​យ៉ាងហោចណាស់​ត្រូវ​ជ្រើស​ទីតាំង​មួយ';
$lang['messages_must_write_message'] = 'អ្នក​ត្រូវតែ​បញ្ចូល​សារ​មួយ';
$lang['messages_new_message'] = 'សារថ្មី';
?>