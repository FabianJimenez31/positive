<?php
$lang["home_todays_closeout_report"] = "របាយការណ៍​បិទ​លក់​ថ្ងៃ​នេះ";
$lang["home_todays_detailed_sales_report"] = "របាយការណ៍​លក់​លម្អិត​ថ្ងៃ​នេះ";
$lang["home_todays_summary_items_report"] = "របាយការណ៍​ទំនិញ​សង្ខេប​ថ្ងៃ​នេះ";
$lang["home_receivings_start_new_receiving"] = "ចាប់ផ្ដើម​ទទួល​ថ្មី";
$lang["home_mercury_activate_promo_text"] = "កម្មវិធី​លក់​នេះ​រួមបញ្ចូល​ដំណើរការ​ប័ណ្ណ​ឥណទាន​ជាមួយ​ក្រុមហ៊ុន​លក់​ជា​ច្រើន។ នេះ​នឹង​អនុញ្ញាត​ឲ្យ​អ្នក​ប្រមូល​ការ​ទូទាត់​ពី​ម៉ាក​កាត​មាន​ប្រជាប្រិយភាព​ដូច​ជា Visa, Mastercard និង American Express ។ សូម​ចុច​ទីនេះ​ដើម្បី​ស្វែងយល់​បន្ថែម​អំពី​អ្វី​ដែល​យើង​ផ្ដល់​ជូន។";
$lang["home_welcome_message"] = "សូម​ស្វាគមន៍​មក​កាន់​កម្មវិធី​លក់ សូម​ជ្រើសរើស​កិច្ចការ​ទូទៅ​ដូច​ខាងក្រោម​ដើម្បី​ចាប់​ផ្ដើម!";
$lang["home_ecommerce_platform_sync"] = "ស្ថានភាព​សម​កាល​កម្ម​កម្មវិធី​អ៊ី​ពាណិជ្ជកម្ម";
?>