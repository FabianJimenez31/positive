<?php


$lang["timeclocks_logout_without_clock_out"] = "កត់​ចេញ​ដោយ​ពុំ​បាន​កត់​ម៉ោង​ចេញ";
$lang["timeclocks_clock_in_success"] = "អ្នក​បាន​កត់​ម៉ោង​ចូល​ដោយ​ជោគជ័យ";
$lang["timeclocks_clock_in_failure"] = "ពុំ​អាច​កត់​ម៉ោង​ចូល​បាន";
$lang["timeclocks_clock_out_success"] = "អ្នក​បាន​កត់​ម៉ោង​ចេញ​បាន​ដោយ​ជោគជ័យ";
$lang["timeclocks_clock_out_failure"] = "ពុំ​អាច​កត់​ម៉ោង​ចេញ​បាន";
$lang["timeclocks_timeclock_info"] = "ព័ត៌មាន​កត់​ម៉ោង";
$lang["timeclocks_my_punches"] = "ដែក​ចោះ​ខ្ញុំ";
?>