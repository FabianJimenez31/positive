<?php
$lang["error_no_permission_module"] = "អ្នក​ពុំ​មាន​សិទ្ធិ​ចូល​ដំណើរការ​ម៉ូឌុល​ដែល​មាន​ឈ្មោះ";
$lang["error_unknown"] = "មិន​ស្គាល់";
?>