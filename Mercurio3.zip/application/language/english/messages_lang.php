<?php
$lang['messages_sent_messages'] = 'Sent Messages';
$lang['messages_no_messages'] = 'There are no messages';
$lang['messages_inbox'] = 'Inbox';
$lang['messages_message_deleted'] = 'Message deleted successfully';
$lang['messages_employees_required'] = 'You must select at least one employee';
$lang['messages_locations_required'] = 'You must select at least one location';
$lang['messages_must_write_message'] = 'You must enter a message';
$lang['messages_new_message'] = 'New Message';
?>