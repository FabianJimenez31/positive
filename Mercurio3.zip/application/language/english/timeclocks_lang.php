<?php


$lang['timeclocks_logout_without_clock_out'] = 'Logout WITHOUT clocking out';
$lang['timeclocks_clock_in_success'] = 'You have successfully clocked in';
$lang['timeclocks_clock_in_failure'] = 'Unable to clock in';
$lang['timeclocks_clock_out_success'] = 'You have successfully clocked out';
$lang['timeclocks_clock_out_failure'] = 'Unable to clock out';
$lang['timeclocks_timeclock_info'] = 'Time clock info';
$lang['timeclocks_my_punches'] = 'My punches';
?>