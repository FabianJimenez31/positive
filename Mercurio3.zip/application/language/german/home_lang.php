<?php
$lang['home_todays_closeout_report'] = 'Heutiger Ladenschluss-Bericht';
$lang['home_todays_detailed_sales_report'] = 'Heutiger Ladenschluss-Bericht (detailliert)';
$lang['home_todays_summary_items_report'] = 'Heutiger Artikelbericht (zusammengefasst)';

$lang['home_receivings_start_new_receiving'] = 'Neuen Einkauf starten';
$lang['home_mercury_activate_promo_text'] = 'Mercurio integriert Kreditkartenzahlungen durch viele Anbieter. Dies ermöglicht Ihnen, Zahlungen durch beliebte Kartenmarken wie Visa, Mastercard oder American Express zu erhalten. Klicken Sie hier, um mehr über unser Angebot erfahren.';
$lang['home_welcome_message'] = 'Willkommen bei Mercurio! Wählen Sie unten eine gemeinsame Aufgabe, um zu beginnen!';
$lang['home_ecommerce_platform_sync'] = 'E-Commerce-Plattform Sync-Status';
?>