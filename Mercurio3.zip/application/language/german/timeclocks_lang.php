<?php
$lang['timeclocks_logout_without_clock_out'] = 'Abmelden OHNE ausstempeln';
$lang['timeclocks_clock_in_success'] = 'Sie haben erfolgreich eingestempelt';
$lang['timeclocks_clock_in_failure'] = 'Sie konnten nicht eingestempelt werden';
$lang['timeclocks_clock_out_success'] = 'Sie haben erfolgreich ausgestempelt';
$lang['timeclocks_clock_out_failure'] = 'Sie konnten nicht ausstempelt werden';
$lang['timeclocks_timeclock_info'] = 'Zeiterfassungs-Informationen';
$lang['timeclocks_my_punches'] = 'Meine Schläge';
?>