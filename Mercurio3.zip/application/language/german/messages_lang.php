<?php
$lang['messages_sent_messages'] = 'Gesendete Nachrichten';
$lang['messages_no_messages'] = 'Keine Nachrichten gefunden';
$lang['messages_inbox'] = 'Posteingang';
$lang['messages_message_deleted'] = 'Nachricht erfolgreich gelöscht';
$lang['messages_employees_required'] = 'Bitte mindestens einen Mitarbeiter auswählen';
$lang['messages_locations_required'] = 'Bitte mindestens einen Standort auswählen';
$lang['messages_must_write_message'] = 'Die &gt;&gt;Nachricht&lt;&lt; ist erforderlich';
$lang['messages_new_message'] = 'Neue Nachricht';
?>