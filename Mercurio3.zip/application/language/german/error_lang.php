<?php
$lang['error_no_permission_module'] = 'Sie haben keine Berechtigung, um das folgende Modul aufzurufen: ';
$lang['error_unknown'] = 'unbekannt';
?>