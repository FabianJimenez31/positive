<?php
$lang['home_todays_closeout_report'] = 'Laporan obral hari ini';
$lang['home_todays_detailed_sales_report'] = 'Laporan penjualan rinci hari ini';
$lang['home_todays_summary_items_report'] = 'Hari ini barang Ringkasan melaporkan';

$lang['home_receivings_start_new_receiving'] = 'Mulai Menerima New';
$lang['home_mercury_activate_promo_text'] = 'Mercurio terintegrasi dengan pemrosesan kartu kredit dengan banyak vendor. Ini akan memungkinkan Anda untuk mengumpulkan pembayaran dari merek kartu populer seperti Visa, Mastercard dan American Express. Klik di sini untuk mempelajari lebih lanjut tentang penawaran kami.';
$lang['home_welcome_message'] = 'Selamat Datang di Mercurio, pilih tugas umum di bawah untuk memulai!';
$lang['home_ecommerce_platform_sync'] = 'E-commerce Status Landasan Sync';
?>