<?php


$lang['timeclocks_logout_without_clock_out'] = 'Logout TANPA clocking keluar';
$lang['timeclocks_clock_in_success'] = 'Anda telah berhasil clock';
$lang['timeclocks_clock_in_failure'] = 'Tidak dapat jam di';
$lang['timeclocks_clock_out_success'] = 'Anda telah berhasil mencatat keluar';
$lang['timeclocks_clock_out_failure'] = 'Tidak dapat jam keluar';
$lang['timeclocks_timeclock_info'] = 'Waktu jam Info';
$lang['timeclocks_my_punches'] = 'pukulan saya';
?>