<?php
$lang['messages_sent_messages'] = 'Pesan yang dikirim';
$lang['messages_no_messages'] = 'Tidak ada pesan';
$lang['messages_inbox'] = 'Inbox';
$lang['messages_message_deleted'] = 'Pesan berhasil dihapus';
$lang['messages_employees_required'] = 'Anda harus memilih setidaknya satu karyawan';
$lang['messages_locations_required'] = 'Anda harus memilih setidaknya satu lokasi';
$lang['messages_must_write_message'] = 'Anda harus memasukkan pesan';
$lang['messages_new_message'] = 'Pesan baru';
?>