<?php
$lang['home_todays_closeout_report'] = 'Closeout verslag van vandaag';
$lang['home_todays_detailed_sales_report'] = 'Gedetailleerde verkoop verslag van vandaag';
$lang['home_todays_summary_items_report'] = 'Vandaag de samenvatting artikelen rapporteren';

$lang['home_receivings_start_new_receiving'] = 'Start een nieuw Ontvangen';
$lang['home_mercury_activate_promo_text'] = 'Mercurio integreert met credit card processing met vele leveranciers. Dit zal u toelaten om de betaling te verzamelen van populaire kaart merken zoals Visa, Mastercard en American Express. Klik hier voor meer informatie over ons aanbod te leren.';
$lang['home_welcome_message'] = 'Welkom op Mercurio, kiezen voor een gemeenschappelijke taak hieronder om te beginnen!';
$lang['home_ecommerce_platform_sync'] = 'E-commerce Platform Sync Status';
?>