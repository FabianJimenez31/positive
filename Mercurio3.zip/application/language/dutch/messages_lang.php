<?php
$lang['messages_sent_messages'] = 'Verzonden berichten';
$lang['messages_no_messages'] = 'Er zijn geen berichten';
$lang['messages_inbox'] = 'inbox';
$lang['messages_message_deleted'] = 'Bericht succesvol verwijderd';
$lang['messages_employees_required'] = 'U moet minstens één werknemer selecteren';
$lang['messages_locations_required'] = 'U moet ten minste één locatie te kiezen';
$lang['messages_must_write_message'] = 'U dient een bericht in te vullen';
$lang['messages_new_message'] = 'Nieuw bericht';
?>