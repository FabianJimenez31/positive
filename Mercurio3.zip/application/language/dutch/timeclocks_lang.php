<?php


$lang['timeclocks_logout_without_clock_out'] = 'Uitloggen ZONDER klokken uit';
$lang['timeclocks_clock_in_success'] = 'Je hebt met succes geklokt in';
$lang['timeclocks_clock_in_failure'] = 'Niet in staat om de klok in';
$lang['timeclocks_clock_out_success'] = 'Je hebt met succes uit geklokt';
$lang['timeclocks_clock_out_failure'] = 'Niet in staat om de klok uit';
$lang['timeclocks_timeclock_info'] = 'Prikklok info';
$lang['timeclocks_my_punches'] = 'mijn stoten';
?>