<?php
//You do not have permission to access the module named
$lang['error_no_permission_module'] = '您沒有權限訪問名為的模塊';
//unknown
$lang['error_unknown'] = '未知';
?>