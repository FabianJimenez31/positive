<?php
//Logout WITHOUT clocking out
$lang['timeclocks_logout_without_clock_out'] = '註銷不計時';
//You have successfully clocked in
$lang['timeclocks_clock_in_success'] = '你已經成功地進來了';
//Unable to clock in
$lang['timeclocks_clock_in_failure'] = '無法進入';
//You have successfully clocked out
$lang['timeclocks_clock_out_success'] = '你已經成功超時了';
//Unable to clock out
$lang['timeclocks_clock_out_failure'] = '無法超時';
//Time clock info
$lang['timeclocks_timeclock_info'] = '時間信息';
//My punches
$lang['timeclocks_my_punches'] = '我的拳';
?>