<?php
//Today's closeout report
$lang['home_todays_closeout_report'] = '今天的報告';
//Today's detailed sales report
$lang['home_todays_detailed_sales_report'] = '今日詳細銷售報告';
//Today's summary items report
$lang['home_todays_summary_items_report'] = '今天的摘要項目報告';
//Start a New Receiving
$lang['home_receivings_start_new_receiving'] = '開始新接收';
//Mercurio integrates with credit card processing with many vendors. This will allow you to collect payment from popular card brands such as Visa, Mastercard and American Express. Click here to learn more about our offerings.
$lang['home_mercury_activate_promo_text'] = 'PHP銷售點與許多供應商的信用卡處理相結合。這將允許您從流行卡品牌（如Visa，萬事達卡和美國運通）收取付款。點擊這裡了解更多關於我們的產品。';
//Welcome to Mercurio, choose a common task below to get started!
$lang['home_welcome_message'] = '歡迎來到Mercurio，選擇下面的常見任務開始吧！';
//Ecommerce Platform Sync Status
$lang['home_ecommerce_platform_sync'] = '電子商務平台同步狀態';
?>