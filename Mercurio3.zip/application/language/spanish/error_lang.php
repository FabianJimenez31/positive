<?php
$lang['error_no_permission_module']='No tiene permiso para acceder al módulo';
$lang['error_unknown']='Desconocido';
?>