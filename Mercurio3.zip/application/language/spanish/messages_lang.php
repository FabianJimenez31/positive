<?php
$lang['messages_sent_messages'] = 'Mensajes enviados';
$lang['messages_no_messages'] = 'No hay mensajes';
$lang['messages_inbox'] = 'Bandeja de entrada';
$lang['messages_message_deleted'] = 'Mensaje eliminado de manera exitosa';
$lang['messages_employees_required'] = 'Debe seleccionar al menos un empleado';
$lang['messages_locations_required'] = 'Debe seleccionar al menos una ubicación';
$lang['messages_must_write_message'] = 'Debe introducir un mensaje';
$lang['messages_new_message'] = 'Nuevo mensaje';
?>