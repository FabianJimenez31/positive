<?php


$lang['timeclocks_logout_without_clock_out'] = 'Salir sin registrar hora de salida';
$lang['timeclocks_clock_in_success'] = 'Se ha registrado su entrada con éxito';
$lang['timeclocks_clock_in_failure'] = 'Error al registrar su hora de entrada, intente de nuevo';
$lang['timeclocks_clock_out_success'] = 'Se registró su hora de salida con éxito';
$lang['timeclocks_clock_out_failure'] = 'Error al registrar su hora de salida, intente de nuevo';
$lang['timeclocks_timeclock_info'] = 'Información del reloj checador';
$lang['timeclocks_my_punches'] = 'mis golpes';
?>