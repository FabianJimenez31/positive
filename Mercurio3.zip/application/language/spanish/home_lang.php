<?php
$lang['home_todays_closeout_report'] = 'Reporte del cierre de hoy';
$lang['home_todays_detailed_sales_report'] = 'Reporte detallado de ventas de hoy';
$lang['home_todays_summary_items_report'] = 'Reporte resumido de artículos de hoy';

$lang['home_receivings_start_new_receiving'] = 'Iniciar una nueva entrada';
$lang['home_mercury_activate_promo_text'] = 'Mercurio se integra con el procesamiento de tarjetas de crédito con muchos proveedores. Esto le permitirá recoger el pago de las marcas de tarjetas populares, tales como Visa, Mastercard y American Express. Haga clic aquí para aprender más sobre nuestras ofertas.';
$lang['home_welcome_message'] = '¡Bienvenido a Mercurio, seleccione una opción para comenzar!';
$lang['home_ecommerce_platform_sync'] = 'Comercio electrónico Plataforma estado de la sincronización';
?>