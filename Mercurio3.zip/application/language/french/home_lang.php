<?php
$lang['home_todays_closeout_report'] = 'Le rapport de clôture d\'aujourd\'hui';
$lang['home_todays_detailed_sales_report'] = 'Rapport détaillé des ventes d\'aujourd\'hui';
$lang['home_todays_summary_items_report'] = 'Les articles sommaires aujourd\'hui le rapport';

$lang['home_receivings_start_new_receiving'] = 'Commencer un nouveau dépôt';
$lang['home_mercury_activate_promo_text'] = 'Mercurio intègre avec le traitement des cartes de crédit avec de nombreux fournisseurs. Cela vous permettra de recueillir le paiement de marques de cartes populaires tels que Visa, Mastercard et American Express. Cliquez ici pour en savoir plus sur nos offres.';
$lang['home_welcome_message'] = 'Welcome to Mercurio, choisissez une tâche commune ci-dessous pour commencer!';
$lang['home_ecommerce_platform_sync'] = 'Ecommerce Platform Sync Status';
?>