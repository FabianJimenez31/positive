<?php


$lang['timeclocks_logout_without_clock_out'] = 'Déconnexion sans poinçonnage de sortie';
$lang['timeclocks_clock_in_success'] = 'Entrée enrégistée avec succès';
$lang['timeclocks_clock_in_failure'] = 'Impossible de poinçonner';
$lang['timeclocks_clock_out_success'] = 'Sortie enrégistée avec succès';
$lang['timeclocks_clock_out_failure'] = 'Impossible de poinçonner';
$lang['timeclocks_timeclock_info'] = 'Information sur l\'entrée de temps';
$lang['timeclocks_my_punches'] = 'Mes coups de poing';
?>