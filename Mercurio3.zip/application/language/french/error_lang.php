<?php
$lang['error_no_permission_module']='Vous n\'avez pas les permission requises pour accéder à ce module'; 
$lang['error_unknown']='Inconnue';
?>