<?php
$lang['messages_sent_messages'] = 'Messages envoyés';
$lang['messages_no_messages'] = 'Il n\'y a pas de messages';
$lang['messages_inbox'] = 'Boîte de réception';
$lang['messages_message_deleted'] = 'Message supprimé avec succès';
$lang['messages_employees_required'] = 'Vous devez sélectionner au moins un employé';
$lang['messages_locations_required'] = 'Vous devez sélectionner au moins un emplacement';
$lang['messages_must_write_message'] = 'Vous devez saisir un message';
$lang['messages_new_message'] = 'Nouveau message';
?>