<?php
$lang['error_no_permission_module']='Não tem permissão para aceder ao módulo chamado';
$lang['error_unknown']='desconhecido';
?>