<?php
$lang['messages_sent_messages'] = 'Mensagens Enviadas';
$lang['messages_no_messages'] = 'Não existem mensagens';
$lang['messages_inbox'] = 'Caixa de entrada';
$lang['messages_message_deleted'] = 'Mensagem eliminada com sucesso';
$lang['messages_employees_required'] = 'Deve selecionar pelo menos um funcionário';
$lang['messages_locations_required'] = 'Deve selecionar pelo menos uma localização';
$lang['messages_must_write_message'] = 'Deve escrever uma mensagem';
$lang['messages_new_message'] = 'Nova mensagem';
?>