<?php
$lang['home_todays_closeout_report'] = 'Relatório de encerramento de hoje';
$lang['home_todays_detailed_sales_report'] = 'Relatório de vendas detalhado de hoje';
$lang['home_todays_summary_items_report'] = 'Relatório de resumo de itens de hoje';

$lang['home_receivings_start_new_receiving'] = 'Iniciar uma Nova Recepção';
$lang['home_mercury_activate_promo_text'] = 'Mercurio integra com o processamento de cartão de crédito com vários fornecedores. Isso permitirá que você para recolher o pagamento de marcas de cartões populares, tais como Visa, Mastercard e American Express. Clique aqui para saber mais sobre nossas ofertas.';
$lang['home_welcome_message'] = 'Bem-vindo ao ponto de venda PHP, escolha uma tarefa comum abaixo para começar!';
$lang['home_ecommerce_platform_sync'] = 'Ecommerce Plataforma Status da Sincronização';
?>