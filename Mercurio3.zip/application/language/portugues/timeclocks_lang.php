<?php


$lang['timeclocks_logout_without_clock_out'] = 'Sair SEM registar';
$lang['timeclocks_clock_in_success'] = 'Registou a entrada com sucesso';
$lang['timeclocks_clock_in_failure'] = 'Não é possível registar a entrada';
$lang['timeclocks_clock_out_success'] = 'Registou a saída com sucesso';
$lang['timeclocks_clock_out_failure'] = 'Não é possível registar a saída';
$lang['timeclocks_timeclock_info'] = 'Informações de relógio';
$lang['timeclocks_my_punches'] = 'meus socos';
?>