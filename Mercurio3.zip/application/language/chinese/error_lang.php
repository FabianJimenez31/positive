<?php
//You do not have permission to access the module named
$lang['error_no_permission_module'] = '您没有权限访问名为的模块';
//unknown
$lang['error_unknown'] = '未知';
?>