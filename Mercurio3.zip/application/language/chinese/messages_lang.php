<?php
//Sent Messages
$lang['messages_sent_messages'] = '发送信息';
//There are no messages
$lang['messages_no_messages'] = '没有消息';
//Inbox
$lang['messages_inbox'] = '收件箱';
//Message deleted successfully
$lang['messages_message_deleted'] = '消息已成功删除';
//You must select at least one employee
$lang['messages_employees_required'] = '您必须至少选择一名员工';
//You must select at least one location
$lang['messages_locations_required'] = '您必须至少选择一个位置';
//You must enter a message
$lang['messages_must_write_message'] = '您必须输入消息';
//New Message
$lang['messages_new_message'] = '新消息';
?>