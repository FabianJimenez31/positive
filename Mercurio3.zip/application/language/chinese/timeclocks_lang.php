<?php
//Logout WITHOUT clocking out
$lang['timeclocks_logout_without_clock_out'] = '注销不计时';
//You have successfully clocked in
$lang['timeclocks_clock_in_success'] = '你已经成功地进来了';
//Unable to clock in
$lang['timeclocks_clock_in_failure'] = '无法进入';
//You have successfully clocked out
$lang['timeclocks_clock_out_success'] = '你已经成功超时了';
//Unable to clock out
$lang['timeclocks_clock_out_failure'] = '无法超时';
//Time clock info
$lang['timeclocks_timeclock_info'] = '时间信息';
//My punches
$lang['timeclocks_my_punches'] = '我的拳';
?>