<?php
$lang['home_todays_closeout_report'] = 'تقرير الانتهاء اليوم';
$lang['home_todays_detailed_sales_report'] = 'تقرير مبيعات مفصل اليوم';
$lang['home_todays_summary_items_report'] = 'بنود ملخص اليوم تقرير';

$lang['home_receivings_start_new_receiving'] = 'بدء استقبال جديدة';
$lang['home_mercury_activate_promo_text'] = 'PHP نقاط البيع يتكامل مع معالجة بطاقات الائتمان مع العديد من البائعين. وهذا سوف يسمح لك لجمع الدفع من العلامات التجارية بطاقة شعبية مثل فيزا، ماستر كارد وأمريكان إكسبريس. انقر هنا لمعرفة المزيد عن عروضنا.';
$lang['home_welcome_message'] = 'مرحبا بكم في PHP نقاط البيع، اختر مهمة مشتركة أدناه لتبدأ!';
$lang['home_ecommerce_platform_sync'] = 'التجارة الإلكترونية منصة مزامنة الحالة';
?>