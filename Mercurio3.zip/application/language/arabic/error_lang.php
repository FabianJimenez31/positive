<?php
$lang['error_no_permission_module']='ليس لديك تصريح بالدخول الى اسم النموذج';
$lang['error_unknown']='غير معرف';
?>