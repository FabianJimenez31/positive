<?php


$lang['timeclocks_logout_without_clock_out'] = 'تسجيل الخروج بدون ختم خروج على الساعة';
$lang['timeclocks_clock_in_success'] = 'تم تسجيل ختم الدخول بنجاح';
$lang['timeclocks_clock_in_failure'] = 'فشل في تسجيل ختم الدخول';
$lang['timeclocks_clock_out_success'] = 'تم تسجيل ختم الخروج بنجاح';
$lang['timeclocks_clock_out_failure'] = 'فشل في تسجيل ختم الخروج';
$lang['timeclocks_timeclock_info'] = 'معلومات ساعة الدوام';
$lang['timeclocks_my_punches'] = 'بلدي اللكمات';
?>