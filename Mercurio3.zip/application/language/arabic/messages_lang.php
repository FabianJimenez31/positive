<?php
$lang['messages_sent_messages'] = 'الرسائل المرسلة';
$lang['messages_no_messages'] = 'لا توجد رسائل';
$lang['messages_inbox'] = 'صندوق الوارد';
$lang['messages_message_deleted'] = 'رسالة حذفها بنجاح';
$lang['messages_employees_required'] = 'يجب تحديد موظف واحد على الأقل';
$lang['messages_locations_required'] = 'يجب تحديد موقع واحد على الأقل';
$lang['messages_must_write_message'] = 'يجب عليك إدخال رسالة';
$lang['messages_new_message'] = 'رسالة جديدة';
?>