<?php




















$lang['giftcards_giftcard_number']='رقم بطاقة الهدية';
$lang['giftcards_id']='الرقم المتسلسل لبطاقة الهدية';
$lang['giftcards_card_value']='القيمة';
$lang['giftcards_basic_information']='معلومات بطاقة الهدية';
$lang['giftcards_number_required']='';
$lang['giftcards_value_required']='قيمة  بطاقة الهدية هو حقل مطلوب';
$lang['giftcards_number']='رقم بطاقة الهدية هو حقل مطلوب';
$lang['giftcards_value']='قيمة بطاقة الهدية يجب ان يكون رقماً';
$lang['giftcards_exists']='رقم بطاقة الهدية موجود';
$lang['giftcards_retrive_giftcard_info']='استرجاع معلومات بطاقة الهدية';

$lang['giftcards_amazon']='امازون';
$lang['giftcards_upc_database']='قاعدة بيانات UPC';
$lang['giftcards_cannot_find_giftcard']='لا يوجد معلومات حول بطاقة الهدية';
$lang['giftcards_info_provided_by']='المعلومات مقدمة من';
$lang['giftcards_number_information']='رقم بطاقة الهدية';
$lang['giftcards_new']='بطاقة هدية جديدة';
$lang['giftcards_update']='تعديل بطاقة الهدية';

$lang['giftcards_edit_multiple_giftcards']='تعديل اكثر من بطاقة هدية';
$lang['giftcards_category']='التصنيف';
$lang['giftcards_cost_price']='سعر التكلفة';
$lang['giftcards_unit_price']='سعر الوحدة';
$lang['giftcards_tax_1']='الضريبة الاولى';
$lang['giftcards_tax_2']='الضريبة الثانية';
$lang['giftcards_sales_tax_1'] = 'ضريبة المبيعات';
$lang['giftcards_sales_tax_2'] = 'ضريبة المبيعات الثانية';
$lang['giftcards_tax_percent']='نسبة الضريبة';
$lang['giftcards_tax_percents']='نسب  الضرائب';
$lang['giftcards_reorder_level']='اعادة ترتيب المستوى';
$lang['giftcards_quantity']='الكمية';











$lang['giftcards_no_giftcards_to_display']='لا يوجد بطاقات هدايا';
$lang['giftcards_bulk_edit']='تعديل جماعي';
$lang['giftcards_confirm_delete']='هل انت متأكد من حذف  البطاقات المختاره';
$lang['giftcards_do_nothing'] = 'لا تفعل شئ';
$lang['giftcards_change_all_to_serialized'] = 'تغيير الكل الى رقم متسلسل';
$lang['giftcards_change_all_to_unserialized'] = 'تغيير الكل لغير متسلسل';
$lang['giftcards_change_all_to_allow_alt_desc'] = 'السماح للكل بـ ALT';
$lang['giftcards_change_all_to_not_allow_allow_desc'] = 'عدم السماح للكل بـ ALT';
$lang['giftcards_use_inventory_menu'] = 'اختيار قائمة المستودعات';
$lang['giftcards_manually_editing_of_quantity'] = 'تعديل يدوي للكمية';

$lang['giftcards_none_selected'] = 'لم تقم بتحديد اي بطاقة هدية';
$lang['giftcards_confirm_bulk_edit'] = 'هل انت متاكد انك تريد تعديل كل البطاقات الهدايا المختارة';
$lang['giftcards_successful_bulk_edit'] = 'تم تعديل البطاقات المختاره بنجاح';
$lang['giftcards_error_updating_multiple'] = 'خطا في تعديل البطاقات';
$lang['giftcards_edit_fields_you_want_to_update'] = 'عدل الحقول التي تريد لكل البطاقات المختاره';
$lang['giftcards_error_adding_updating'] = 'خطا في اضافة/تعديل البطاقة';
$lang['giftcards_successful_adding'] = 'تم اضافة البطاقة بنجاح';
$lang['giftcards_successful_updating'] = 'تم تعديل البطاقة بنجاح';
$lang['giftcards_successful_deleted'] = 'تم الحذف  بنجاح';
$lang['giftcards_one_or_multiple'] = 'بطاقة  (بطاقات)';
$lang['giftcards_cannot_be_deleted'] = 'لا يمكن حذف البطاقات المختاره, واحده منها او اكثر لديها مبيعات';
$lang['giftcards_none'] = 'لا شيء';
$lang['giftcards_supplier'] = 'مورد';
$lang['giftcards_generate_barcodes'] = 'انشاء الباركود';
$lang['giftcards_must_select_giftcard_for_barcode'] = 'يجب اختار بطاقة على الاقل لتوليد الباركود';
$lang['giftcards_excel_import_failed'] = 'فشل في تحميل الاكسل';
$lang['giftcards_allow_alt_desciption'] = 'السماح لوصف ال ALt';
$lang['giftcards_is_serialized'] = 'بطاقة الهدايا لديها رقم تسلسلي';
$lang['giftcards_low_inventory_giftcards'] = 'مخزون منخفض في المستودع';
$lang['giftcards_serialized_giftcards'] = 'التسلسل لبطاقات الهدايا';
$lang['giftcards_no_description_giftcards'] = 'لا يوجد وصف لبطاقة الهدية';
$lang['giftcards_inventory_comments'] = 'التعليقات';
$lang['giftcards_count'] = 'تعديل المستودع';
$lang['giftcards_details_count'] = 'تفاصيل اعداد المستودع';
$lang['giftcards_add_minus'] = 'اضافة او طرح للمستودع';
$lang['giftcards_current_quantity'] = 'الكمية الحالية';
$lang['giftcards_quantity_required'] = 'الكمية حقل مطلوب';
$lang['giftcards_created_giftcard_with_value'] = 'خلق جيفتكارد بقيمة';
$lang['giftcards_with_a_new_value_of'] = 'مع قيمة جديدة لل';
$lang['giftcards_to_giftcard_with_value_of'] = 'لجيفتكارد مع قيمة جديدة لل';
$lang['giftcards_added'] = 'وأضاف';
$lang['giftcards_removed'] = 'إزالة';
$lang['giftcards_create'] = 'خلق';
$lang['giftcards_log'] = 'جيفتكارد تسجيل';
$lang['giftcards_new_items_import'] = 'تحميل قالب Excel لNEW بطاقات الهدايا';
$lang['giftcards_update_items_import'] = 'تحميل قالب ليوجد من بطاقات الهدايا';
$lang['giftcards_step_1_desc'] = 'تحميل ملف اكسل قالب لإضافة بطاقات الهدايا / تحديث';
$lang['giftcards_step_2_desc'] = 'تحميل الملف من الخطوة 1 لإتمام بطاقات الهدايا الإضافات / التحديثات';
$lang['giftcards_duplicate_giftcard'] = 'خطأ غير قادر على حفظ بطاقة هدية؛ موجود بالفعل';
$lang['giftcards_import_success'] = 'كان استيراد بطاقات هدية النجاح';
$lang['giftcards_buy'] = 'شراء بطاقات الهدايا';
$lang['giftcards_spent'] = 'أنفق';
$lang['giftcards_import_giftcards'] = 'استيراد Giftcards';
?>