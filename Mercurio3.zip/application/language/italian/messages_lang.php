<?php
$lang['messages_sent_messages'] = 'Messaggi inviati';
$lang['messages_no_messages'] = 'Non ci sono messaggi';
$lang['messages_inbox'] = 'Posta in arrivo';
$lang['messages_message_deleted'] = 'Messaggio cancellato con successo';
$lang['messages_employees_required'] = 'È necessario selezionare almeno un dipendente';
$lang['messages_locations_required'] = 'È necessario selezionare almeno una località';
$lang['messages_must_write_message'] = 'Devi inserire un messaggio';
$lang['messages_new_message'] = 'Nuovo messaggio';
?>