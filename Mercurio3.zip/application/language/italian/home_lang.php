<?php
$lang['home_todays_closeout_report'] = 'Rapporto closeout di oggi';
$lang['home_todays_detailed_sales_report'] = 'Dettagliato rapporto di vendite di oggi';
$lang['home_todays_summary_items_report'] = 'Elementi di sintesi di oggi riportano';

$lang['home_receivings_start_new_receiving'] = 'Inizia un nuovo Ricezione';
$lang['home_mercury_activate_promo_text'] = 'Mercurio si integra con l\'elaborazione di carta di credito con molti fornitori. Questo vi permetterà di raccogliere il pagamento da popolari marche di carte come Visa, Mastercard e American Express. Clicca qui per saperne di più sulle nostre offerte.';
$lang['home_welcome_message'] = 'Welcome to Mercurio, scegliere un compito comune di seguito per iniziare!';
$lang['home_ecommerce_platform_sync'] = 'Ecommerce Platform Sync Stato';
?>