<?php
$lang['error_no_permission_module']='Non si dispone di autorizzazione per accedere al modulo denominato';
$lang['error_unknown']='sconosciuto';
?>