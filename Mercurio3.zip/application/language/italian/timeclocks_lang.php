<?php


$lang['timeclocks_logout_without_clock_out'] = 'Logout SENZA clock fuori';
$lang['timeclocks_clock_in_success'] = 'Hai cronometrato con successo in';
$lang['timeclocks_clock_in_failure'] = 'Impossibile orologio';
$lang['timeclocks_clock_out_success'] = 'Hai clock successo';
$lang['timeclocks_clock_out_failure'] = 'Incapace di clock out';
$lang['timeclocks_timeclock_info'] = 'Informazioni tempo orologio';
$lang['timeclocks_my_punches'] = 'I miei pugni';
?>