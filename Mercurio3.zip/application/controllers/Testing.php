<?php
class Testing extends CI_Controller
{
	function index()
	{
		echo '1';
	}
}